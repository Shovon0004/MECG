"""
Script to generate notebooks/03_video_downloading.ipynb
"""

import json
from pathlib import Path


def make_notebook(cells):
    return {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "codemirror_mode": {"name": "ipython", "version": 3},
                "file_extension": ".py",
                "mimetype": "text/x-python",
                "name": "python",
                "nbconvert_exporter": "python",
                "pygments_lexer": "ipython3",
                "version": "3.10.0"
            }
        },
        "nbformat": 4,
        "nbformat_minor": 5
    }


def markdown_cell(source):
    if isinstance(source, str):
        source = [line + "\n" for line in source.split("\n")]
        if source:
            source[-1] = source[-1].rstrip("\n")
    return {"cell_type": "markdown", "metadata": {}, "source": source}


def code_cell(source):
    if isinstance(source, str):
        source = [line + "\n" for line in source.split("\n")]
        if source:
            source[-1] = source[-1].rstrip("\n")
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source
    }


def create_nb03():
    cells = [
        markdown_cell(
            "# MECG: Multilingual Evidence-Grounded Complaint Generation\n"
            "## Notebook 03: Video Downloading, Validation & Caching\n"
            "\n"
            "**Goal**: Download and validate product complaint videos from the Amazon HLS (`.m3u8`) and direct MP4 URLs "
            "provided in the Com-VID dataset.\n"
            "\n"
            "**Key Capabilities**:\n"
            "1. **FFmpeg & HLS Handling**: Directly streams and transcodes HLS M3U8 playlists into standardized MP4 containers.\n"
            "2. **Deduplication**: Saves videos by `video_url_hash`, automatically preventing repeated downloads of the 86 shared video URLs.\n"
            "3. **Resume Support**: Validates existing videos on disk; skips re-downloading valid files.\n"
            "4. **Pilot Mode**: Runs a small test of 5 videos first to verify connectivity and codec compatibility before full batch runs.\n"
            "5. **Validation**: Inspects duration, resolution, FPS, and audio streams with `ffprobe`."
        ),
        code_cell(
            "# Environment & Kaggle Internet Verification\n"
            "import os\n"
            "import sys\n"
            "import subprocess\n"
            "import shutil\n"
            "from pathlib import Path\n"
            "\n"
            "# Ensure project root in sys.path\n"
            "CURRENT_DIR = Path.cwd()\n"
            "if str(CURRENT_DIR) not in sys.path:\n"
            "    sys.path.append(str(CURRENT_DIR))\n"
            "if str(CURRENT_DIR.parent) not in sys.path:\n"
            "    sys.path.append(str(CURRENT_DIR.parent))\n"
            "\n"
            "# Verify FFmpeg availability\n"
            "ffmpeg_bin = shutil.which('ffmpeg')\n"
            "ffprobe_bin = shutil.which('ffprobe')\n"
            "print(f'FFmpeg binary : {ffmpeg_bin}')\n"
            "print(f'FFprobe binary: {ffprobe_bin}')\n"
            "assert ffmpeg_bin and ffprobe_bin, 'FFmpeg and FFprobe must be installed on system!'"
        ),
        markdown_cell(
            "### 1. Configure Paths & Check Cleaned Dataset\n"
            "Detects Kaggle vs local paths and loads `ComVID_cleaned.csv`."
        ),
        code_cell(
            "# Path Resolution\n"
            "if Path('/kaggle/input/comvid-dataset/ComVID_cleaned.csv').exists():\n"
            "    CLEANED_CSV = Path('/kaggle/input/comvid-dataset/ComVID_cleaned.csv')\n"
            "elif Path('data/processed/ComVID_cleaned.csv').exists():\n"
            "    CLEANED_CSV = Path('data/processed/ComVID_cleaned.csv')\n"
            "else:\n"
            "    CLEANED_CSV = Path('../data/processed/ComVID_cleaned.csv')\n"
            "\n"
            "VIDEO_DIR = Path('data/videos')\n"
            "REPORT_PATH = Path('reports/video_download_report.json')\n"
            "VIDEO_DIR.mkdir(parents=True, exist_ok=True)\n"
            "REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)\n"
            "\n"
            "print(f'Cleaned CSV : {CLEANED_CSV.resolve()}')\n"
            "print(f'Video Output: {VIDEO_DIR.resolve()}')"
        ),
        markdown_cell(
            "### 2. Run Pilot Video Download (5 Videos)\n"
            "We run `VideoDownloader` in pilot mode to download and validate 5 sample videos. "
            "In Kaggle, ensure 'Internet' is toggled ON in notebook settings."
        ),
        code_cell(
            "from src.vision.video_downloader import VideoDownloader\n"
            "from src.vision.video_validator import VideoValidator\n"
            "\n"
            "# Initialize Downloader in Pilot Mode (5 videos)\n"
            "downloader = VideoDownloader(\n"
            "    video_dir=VIDEO_DIR,\n"
            "    report_path=REPORT_PATH,\n"
            "    timeout_seconds=60,\n"
            "    max_retries=3,\n"
            "    pilot_mode=True,\n"
            "    pilot_size=5\n"
            ")\n"
            "\n"
            "print('Starting Pilot Download (5 videos)...')\n"
            "pilot_report = downloader.download_dataset(csv_path=CLEANED_CSV, limit=5)\n"
            "\n"
            "print('\\nPilot Download Summary:')\n"
            "for k, v in pilot_report['summary'].items():\n"
            "    print(f'  {k:20s}: {v}')"
        ),
        markdown_cell(
            "### 3. Inspect Downloaded Video Stream Metadata\n"
            "Let's inspect the video files downloaded during the pilot run using `VideoValidator`."
        ),
        code_cell(
            "import glob\n"
            "\n"
            "downloaded_files = sorted(list(VIDEO_DIR.glob('*.mp4')))\n"
            "print(f'Total MP4 files present in {VIDEO_DIR}: {len(downloaded_files)}\\n')\n"
            "\n"
            "for vid in downloaded_files[:5]:\n"
            "    info = VideoValidator.inspect(vid)\n"
            "    print(f\"File: {vid.name}\")\n"
            "    print(f\"  Valid      : {info['is_valid']}\")\n"
            "    print(f\"  Resolution : {info['width']}x{info['height']}\")\n"
            "    print(f\"  FPS        : {info['fps']}\")\n"
            "    print(f\"  Duration   : {info['duration_seconds']}s\")\n"
            "    print(f\"  Has Audio  : {info['has_audio']} ({info.get('audio_codec')})\")\n"
            "    print(f\"  File Size  : {info['file_size_bytes'] / (1024*1024):.2f} MB\")\n"
            "    print('-' * 40)"
        ),
        markdown_cell(
            "### 4. Full Dataset Batch Download (Optional / On-Demand)\n"
            "To download the entire dataset, set `run_full_download = True`. "
            "Thanks to hash deduplication and resume checking, interrupted downloads can be restarted safely without re-downloading."
        ),
        code_cell(
            "run_full_download = False  # Set to True to trigger full batch download\n"
            "\n"
            "if run_full_download:\n"
            "    batch_downloader = VideoDownloader(\n"
            "        video_dir=VIDEO_DIR,\n"
            "        report_path=REPORT_PATH,\n"
            "        timeout_seconds=60,\n"
            "        max_retries=3,\n"
            "        pilot_mode=False\n"
            "    )\n"
            "    print('Starting Full Dataset Download...')\n"
            "    full_report = batch_downloader.download_dataset(csv_path=CLEANED_CSV)\n"
            "    print('Full Download Summary:', full_report['summary'])\n"
            "else:\n"
            "    print('Skipping full download. Pilot verification complete.')"
        ),
        markdown_cell(
            "### Summary & Next Steps\n"
            "- Pilot downloading, validation, and metadata extraction are working.\n"
            "- Deduplication and resume capabilities protect against redundant network transfers.\n"
            "- Proceed to **Notebook 04: Multimodal Preprocessing** for frame sampling and audio extraction."
        )
    ]
    return make_notebook(cells)


def main():
    nb03 = create_nb03()
    with open("notebooks/03_video_downloading.ipynb", "w", encoding="utf-8") as f:
        json.dump(nb03, f, indent=2)
    print("Created notebooks/03_video_downloading.ipynb")


if __name__ == "__main__":
    main()
