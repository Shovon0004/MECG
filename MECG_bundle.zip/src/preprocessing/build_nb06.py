"""
Script to generate notebooks/06_aspect_emotion_training.ipynb
"""

import json
from pathlib import Path


def make_notebook(cells):
    return {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "codemirror_mode": {"name": "ipython", "version": 3},
                "file_extension": ".py",
                "mimetype": "text/x-python",
                "name": "python",
                "nbconvert_exporter": "python",
                "pygments_lexer": "ipython3",
                "version": "3.10.0"
            }
        },
        "nbformat": 4,
        "nbformat_minor": 5
    }


def markdown_cell(source):
    if isinstance(source, str):
        source = [line + "\n" for line in source.split("\n")]
        if source:
            source[-1] = source[-1].rstrip("\n")
    return {"cell_type": "markdown", "metadata": {}, "source": source}


def code_cell(source):
    if isinstance(source, str):
        source = [line + "\n" for line in source.split("\n")]
        if source:
            source[-1] = source[-1].rstrip("\n")
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source
    }


def create_nb06():
    cells = [
        markdown_cell(
            "# MECG: Multilingual Evidence-Grounded Complaint Generation\n"
            "## Notebook 06: Aspect & Emotion Classifier Training\n"
            "\n"
            "**Goal**: Train supervised text classifiers using `microsoft/deberta-v3-base` on the leak-free splits "
            "of `ComVID_cleaned.csv`:\n"
            "1. **Aspect Multi-Label Classifier**: Identifies multiple complaint aspects (Quality, Usability, Manufacturing, Functionality, etc.) "
            "using `BCEWithLogitsLoss` with positive class weight scaling.\n"
            "2. **Emotion Multi-Class Classifier**: Predicts customer emotion across the 4 canonical classes "
            "(`blame`, `disappointment`, `dissatisfaction`, `frustration`) using weighted `CrossEntropyLoss`.\n"
            "3. **Leakage Isolation**: Strictly uses `split == 'train'` for training and `split == 'val'` for validation.\n"
            "4. **Evaluation**: Evaluates Micro-F1, Macro-F1, and per-class metrics."
        ),
        code_cell(
            "# Environment & Dependencies Verification\n"
            "import os\n"
            "import sys\n"
            "import json\n"
            "from pathlib import Path\n"
            "\n"
            "CURRENT_DIR = Path.cwd()\n"
            "if str(CURRENT_DIR) not in sys.path:\n"
            "    sys.path.append(str(CURRENT_DIR))\n"
            "if str(CURRENT_DIR.parent) not in sys.path:\n"
            "    sys.path.append(str(CURRENT_DIR.parent))\n"
            "\n"
            "import torch\n"
            "print(f'PyTorch Version : {torch.__version__}')\n"
            "print(f'CUDA Available  : {torch.cuda.is_available()}')\n"
            "if torch.cuda.is_available():\n"
            "    print(f'Device Name     : {torch.cuda.get_device_name(0)}')\n"
            "\n"
            "from src.classification.aspect_classifier import AspectClassifier\n"
            "from src.classification.emotion_classifier import EmotionClassifier\n"
            "print('Classification modules loaded successfully!')"
        ),
        markdown_cell(
            "### 1. Inspect Training and Validation Data Splits\n"
            "We verify that `split == 'train'` (940 samples) and `split == 'val'` (118 samples) are loaded "
            "without any video-level data leakage."
        ),
        code_cell(
            "import csv\n"
            "\n"
            "CLEANED_CSV = Path('data/processed/ComVID_cleaned.csv')\n"
            "if not CLEANED_CSV.exists() and Path('/kaggle/input/comvid-dataset/ComVID_cleaned.csv').exists():\n"
            "    CLEANED_CSV = Path('/kaggle/input/comvid-dataset/ComVID_cleaned.csv')\n"
            "\n"
            "train_samples = 0\n"
            "val_samples = 0\n"
            "with open(CLEANED_CSV, 'r', encoding='utf-8') as f:\n"
            "    for row in csv.DictReader(f):\n"
            "        if row['split'] == 'train':\n"
            "            train_samples += 1\n"
            "        elif row['split'] == 'val':\n"
            "            val_samples += 1\n"
            "\n"
            "print(f'Dataset path : {CLEANED_CSV.resolve()}')\n"
            "print(f'Train split  : {train_samples} samples')\n"
            "print(f'Val split    : {val_samples} samples')"
        ),
        markdown_cell(
            "### 2. Train DeBERTa-v3 Multi-Label Aspect Classifier\n"
            "Executes supervised training using `training/train_aspect_classifier.py`."
        ),
        code_cell(
            "from training.train_aspect_classifier import train as train_aspect\n"
            "\n"
            "aspect_checkpoint_dir = 'outputs/checkpoints/aspect_classifier'\n"
            "print('Training Aspect Classifier (5 epochs)...')\n"
            "train_aspect(\n"
            "    csv_path=str(CLEANED_CSV),\n"
            "    output_dir=aspect_checkpoint_dir,\n"
            "    model_id='microsoft/deberta-v3-base',\n"
            "    epochs=5,\n"
            "    batch_size=16,\n"
            "    lr=2e-5,\n"
            "    dry_run=False\n"
            ")\n"
            "print('Aspect Classifier Training Completed!')"
        ),
        markdown_cell(
            "### 3. Train DeBERTa-v3 Emotion Classifier\n"
            "Executes supervised training using `training/train_emotion_classifier.py`."
        ),
        code_cell(
            "from training.train_emotion_classifier import train as train_emotion\n"
            "\n"
            "emotion_checkpoint_dir = 'outputs/checkpoints/emotion_classifier'\n"
            "print('Training Emotion Classifier (5 epochs)...')\n"
            "train_emotion(\n"
            "    csv_path=str(CLEANED_CSV),\n"
            "    output_dir=emotion_checkpoint_dir,\n"
            "    model_id='microsoft/deberta-v3-base',\n"
            "    epochs=5,\n"
            "    batch_size=16,\n"
            "    lr=2e-5,\n"
            "    dry_run=False\n"
            ")\n"
            "print('Emotion Classifier Training Completed!')"
        ),
        markdown_cell(
            "### 4. Test Classifier Predictions\n"
            "Test both trained models on sample customer complaint texts."
        ),
        code_cell(
            "sample_review = 'The plastic bottle cap is completely loose and leaks pungent chemical liquid everywhere.'\n"
            "\n"
            "aspect_clf = AspectClassifier.from_checkpoint(aspect_checkpoint_dir)\n"
            "aspect_preds = aspect_clf.predict(sample_review, threshold=0.4)\n"
            "print(f\"Review: '{sample_review}'\")\n"
            "print(f\"Predicted Aspects: {aspect_preds}\")\n"
            "\n"
            "emotion_clf = EmotionClassifier(checkpoint_dir=emotion_checkpoint_dir)\n"
            "emotion_preds = emotion_clf.predict(sample_review)\n"
            "print(f\"Predicted Emotion: {emotion_preds['predicted_emotion']} (confidence={emotion_preds['confidence']})\")\n"
            "print(f\"Emotion Distribution: {emotion_preds['distribution']}\")"
        ),
        markdown_cell(
            "### Summary & Next Steps\n"
            "- Aspect and Emotion classifiers are trained, evaluated, and checkpointed.\n"
            "- Proceed to **Phase 6: Visual Evidence Extraction** and **Phase 7: Visual Retrieval with SigLIP 2 & FAISS**."
        )
    ]
    return make_notebook(cells)


def main():
    nb06 = create_nb06()
    with open("notebooks/06_aspect_emotion_training.ipynb", "w", encoding="utf-8") as f:
        json.dump(nb06, f, indent=2)
    print("Created notebooks/06_aspect_emotion_training.ipynb")


if __name__ == "__main__":
    main()
